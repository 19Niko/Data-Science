# Question Number 1

select p.Profile_ID , Concat(p.First_name,' ',p.last_name) as Full_Name, p.phone
from profiles p
join tenancy_histories t
on p.profile_id=t.profile_id
where datediff(t.move_out_date,t.move_in_date) = (select max(datediff(move_out_date,move_in_date)) from tenancy_histories);

# Question Number 2
                                             
Select Concat(First_name,' ',last_name) as Full_Name, Email, Phone from profiles
where (
profile_id in (select profile_id from profiles where marital_status = 'Y')
and 
profile_id in (select profile_id from tenancy_histories where rent > 9000));                                            

                                     #OR

Select Concat(p.First_name,' ',p.last_name) as Full_Name, p.Email,p.Phone from profiles p
join tenancy_histories t
on p.profile_id=t.profile_id
where rent > 9000 and marital_status = 'Y';

# Question Number 3

select p.profile_id, concat(p.first_name,' ',p.last_name) as Full_Name, p.Phone, p.Email, p.City, t.House_id, t.move_in_date ,
t.move_out_date, t.Rent, sum(r.referral_valid) as Total_number_of_referral_made, e.latest_employer, e.Occupational_category from profiles p 
join tenancy_histories t on p.profile_id = t.profile_id
join referrals r on p.profile_id = r.referrer_id
join employment_details e on p.profile_id = e.profile_id
where (city = 'Bangalore' or city ='Pune') and (move_in_date>= '2015-01-01' and move_in_date<= '2016-01-01')
group by referrer_id
order by rent desc;

# Question Number 4

select concat(p.first_name,' ', p.last_name) as Full_Name, p.Email, p.referral_code, SUM(CASE WHEN referral_valid=0 then 0 else referrer_bonus_amount end) as bonus from profiles p
join referrals r
on p.profile_id=r.referrer_id
group by referrer_id
having sum(r.referral_valid) > 1;

# Question Number 5

select city , sum(rent) as Total_Rent_per_city from profiles 
join tenancy_histories
on profiles.profile_id= tenancy_histories.profile_id
group by city
union
select 'Total', sum(rent) from tenancy_histories;

# Question Number 6

create view vw_tenant as
select p.profile_id, t.rent, t.move_in_date, h.house_type, h.Beds_vacant, a.description as Address, p.city from tenancy_histories t
join addresses a on a.house_id=t.house_id
join profiles p on p.profile_id=t.profile_id
Join houses h on h.house_id=t.house_id
where t.move_in_date >= '2015-04-30' and Beds_vacant > 0;

# Question Number 7

update referrals set 
valid_till =date_add(valid_till, INTERVAL -1 Month)
where referrer_id in (select referrer_id FROM referrals group by referrer_id having sum(referral_valid) >= 2)
select * from referrals;

# Question Number 8

select p.Profile_ID, Concat(p.First_name,' ', p.Last_name) as Full_Name , P.Phone,
case
when t.rent > 10000 then 'Grade A'
when t.rent between 7500 and 10000 then 'Grade B'
else 'Grade C' end as 'Customer Segment'
from profiles p
join  tenancy_histories t 
on p.Profile_ID=t.Profile_ID;

# Question Number 9

select concat(p.First_name,' ',p.last_name) as Fullname, p.phone, p.email, p.City, h.house_type, h.bhk_details, h.furnishing_type from profiles p
join tenancy_histories t on p.profile_id=t.profile_id
join houses h on h.house_id=t.house_id
join referrals r on p.profile_id=r.referrer_id
where referrer_id in (select referrer_id from referrals where referral_valid > 0 group by referrer_id)
group by referrer_id;

# Question Number 10

select a.name , h.house_type, h.bhk_details, h.furnishing_type, (H.bed_count - H.beds_vacant) as occupancy from Houses h
join addresses a on h.house_id=a.house_id
where (H.bed_count - H.beds_vacant) = (select max(H.bed_count - H.beds_vacant) from houses h);
